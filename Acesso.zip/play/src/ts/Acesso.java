package ts;

import javax.swing.JOptionPane;

public class Acesso {
	String Placa, DataIn, DataOut, HoraIn, HoraOut;
	
	public static void main (String[] args) {
		//To Do:
		// placa, data de entrada e saida, hora de entrada e saida;
		Acesso acao = new Acesso();
		
		try {
		acao.setPlaca("aaaaaaaa");
		acao.getPlaca();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Tipo de placa inv�lida!");
		}

		try {
		acao.setDataIn("ASS-0420");
		acao.getDataIn();
		
		
		acao.setDataOut("20/09/2021");
		acao.getDataOut();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Tipo de data inv�lida!");
		}
		
		
		try {
		acao.setHoraIn("11:10");
		acao.getHoraIn();
		
		acao.setHoraOut("12:30");
		acao.getHoraOut();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Hor�rio inv�lido!");
		}
		
		
	}
	
	

//______________________________________________________________________________________________		
	//metdo para placa__________________________________________________________________________
	
public void setPlaca(String placa) {
		this.Placa = placa;
	}

public String getPlaca() {
	return this.Placa;
}
	
//______________________________________________________________________________________________		
	//metodo para data de entrada_______________________________________________________________
public void setDataIn(String dataIn) {
	this.DataIn = dataIn;
	
}

public String getDataIn() {
	return this.DataIn;
}
	
//______________________________________________________________________________________________	
	// metod para data de saida_________________________________________________________________
public void setDataOut(String dataOut) {
	this.DataOut = dataOut;
}

public String getDataOut() {
	return this.DataOut;
}

//______________________________________________________________________________________________	
	//metodo para hora de entrada_______________________________________________________________
public void setHoraIn(String horaIn) {
	this.HoraIn = horaIn;
}

public String getHoraIn() {
	return this.HoraIn;
}

//______________________________________________________________________________________________	
	//metodo para hora de saida_________________________________________________________________
	
public void setHoraOut(String horaOut) {
	this.HoraOut = horaOut;
}

public String getHoraOut() {
	return this.HoraOut;
}

}



//bruh what now..? ;-;